<?
//检查意向信
function checkAdrMail($womanid,$manid,$agent,$action, $options = null){

	/*
	$womanid 女士编号
	$manid 男士编号
	$agent 机构编号


	$action = 0;   管理区审信
	$action = 1;   进入写信时检测
	$action = 2;   提交信件时检测
	$action = 3;   机构审信时
	$option         男士检测的条件,由于需要特殊处理时,所检测的条件不相同,为了不改动原有程序,所以增加一个默认为空的参数
    */
	
	global $dbhread; #mysql连接,
	global $errMsg;

	$dbinfo['tb_woman']="woman";
	$dbinfo['tb_relation']="relation";
	$dbinfo['tb_agent']="agent";
	$dbinfo['tb_adrmain_all']="ammsg01_new";

	/*公共检测条件*/
	//1.檢查女士資料情况
	$query=" select * from ".$dbinfo['tb_woman']." where womanid='".$womanid."' and status1 in ('0','2') and deleted='0' and owner='".$agent."' ";
	$result=mysql_query($query,$dbhread);
	echo mysql_error();

	$womaninfo = mysql_fetch_assoc($result);
	if ($womaninfo['firstname'] == "" || $womaninfo['lastname'] == "" || $womaninfo['owner'] == "" || $womaninfo['womanid'] != $womanid ) {
		$errMsg['A004']="編號爲&nbsp;<font color='#0000FF'>$womanid</font>&nbsp;的女士會員不存在或不屬於貴機構!<br>請查對你的輸入是否正確!";
		return false;
	}
	
	if ($womaninfo['status1']=='2'){
		$errMsg['A005']="編號爲&nbsp;<font color='#0000FF'>$womanid</font>&nbsp;的女士會員资料已隐藏。<br>禁止发送意向信!";
		return false;	
	}


	if ($womaninfo['problem']=='1'){
		$errMsg['A021']="對不起﹐該女士資料".$womanid."(".$womaninfo['cnname'].") 會員被設定為“疑問資料”﹐系統暫停其意向信件的發送功能。[&nbsp;<A HREF=\"javascript:Show('../assist/lady_confirm_by_woman.php?womanid=".$womanid."')\" class='blue'>請進入解決>></A> ]";
		return false;	
	}
	
	
	//检查女士是否由发送意向信的权限（我司设定）
	 $query="SELECT admirer2 FROM woman_priv WHERE womanid='".$womanid."'";
	  $result=mysql_query($query,$dbhread);
	  $woman_priv_info=mysql_fetch_array($result);
	  if($woman_priv_info['admirer2']==0){
		  $errMsg['A026']="編號爲&nbsp;<font color='#0000FF'>$womanid</font>&nbsp;的女士會員资料已被禁止发送意向信!";
			return false;				
	  }
	


	//2.檢查男士資料情况
    $memberdb=new MemberDB();
    $table=array('info_core','info_basic',TABLE_INFO_SITE); # info_core, info_basic 男士资料库表名,SQL相当于: SELECT * FROM info_core,info_basic WHERE info_core.manid=info_basic.manid;

    if($action==0){
        $table[]='info_physical';
        $field=array('id','manid','email','firstname','lastname','admirer_notify','sid','paid_amount','chnlove');
    }else{
        $table[]='info_desc';
        $table[]=TABLE_INFO_MATCH;
        $field='';
    }
	
   
	if(strlen(trim($manid))==0){
		$errMsg['A023']="Gentleman with the ID <font color='#0000FF'>$manid</font> does not exist.";
		return false;		
	}

    $options    =   empty($options) ? array('where'=>"status=0 AND permit='Y'") : $options;

    $maninfo=$memberdb->GetMemberInfo($manid,$field,$table,$options);
    //男士自行注销检测
	if($maninfo['chnlove']==0){  //其它三个站的字段分别为: thaimatches,latamdate,charmingdate
		$errMsg['A024']='编号为<font color=\'#0000FF\'>'.$manid.'</font>的男士会员不存在或该帐号目前暂时不可用.';
		return false;
	}
    
	if ($maninfo['firstname'] == "" || $maninfo['manid'] == "" || $maninfo['manid'] != $manid ) {
		$errMsg['A006']="編號爲&nbsp;<font color='#0000FF'>$manid</font>&nbsp;的男士會員不存在或者停止使用服務!";
		return false;
	}

	if($maninfo['sendadm'] == '0' || $maninfo['sendadm2'] == '0'){
		$errMsg['A007']="對不起，系統禁止該意向信件提交！<BR>原因﹕編號爲&nbsp;<font color='#0000FF'>$manid</font>&nbsp;的男士會員拒收意向信!";
		return false;
	}

	if( $maninfo['marry'] == '5'){
		$errMsg['A008']="對不起，系統禁止該意向信件提交！<BR>原因﹕編號爲&nbsp;<font color='#0000FF'>$manid</font>&nbsp;的男士會員當前爲在婚狀態，系統禁止給該狀態下的男士發送意向信!";
		return false;
	}

    if($maninfo['paid_amount']>0){
        $paidmember=true;
        $agentmaxnumin24hour=5;
        $manmaxnumoneday=6;	//消費會員： 每人每日收取限額為 6 封 2011/12/9 jeffrey
        $womanmaxnumemf=15;
    }else{
        $paidmember=false;
        $agentmaxnumin24hour=100;
        $manmaxnumoneday=6;	//未消費會員： 每人每日收取限額為 6 封 2011/12/9 jeffrey
        $womanmaxnumemf=15;
    }


	//3.檢查是否有EMF通信關係 或者女士是否给男人发过首封emf
	$query="select * from ".$dbinfo['tb_relation']." where womanid='".$womanid."' and manid='".$manid."'";
	$result=mysql_query($query,$dbhread);
	echo mysql_error();
	$relation_rs = mysql_fetch_assoc($result);
	if ($relation_rs['mw_num']>0 || $relation_rs['wm_reply_num']>0  ) {
		$errMsg['A014']="對不起，系統禁止該意向信件提交。<BR>女士和男士會員曾經通過信或正在通信往來中！<BR>請仔細檢查是否有誤! ";

		//更新FAV表
		disableFavoriteAdr($manid,$womanid);

		return false;
	}
	//检查男士是否发过BP信件给女士
	if($relation_rs['integral']!=0){
		$errMsg['A025']="对不起，系统禁止该意向信件提交。<br>男士已向女士發送過積分信件！";
		return false;
	}

	if($action=='2' or $action=='1'){
		//4.檢查代理機構是否開通發意向信
		$query="select admirers,admire_max,admire_sum_balance,admire_reviewer,admire_tpl_reviewer from ".$dbinfo['tb_agent']." where agentid='".$agent."' and admirers='Y'";
		$result=mysql_query($query,$dbhread);
		echo mysql_error();
		if (mysql_num_rows($result)<1){
			$errMsg['A001']="對不起，貴機構的意向信功能通道已被關閉！";
			return false;
		}

		$agentinfo=mysql_fetch_assoc($result);
		$admire_max=$agentinfo['admire_max']+0;         //同一女士一天內(北京時間)發送意向信不能超過机构设定值
		$adr_balance=$agentinfo['admire_sum_balance']+0;


		if($adr_balance<=0 ){
			$errMsg['A020']="<font color=#FF0000>對不起！系統禁止提交該信件！</font><BR>機構當日發信量超出限定值﹗";
			return false;
		}	

		$info['agent']	= $agentinfo;

		//5.同一機構多個女士在短時間內向男士提交過意向信
		$time=date('Y-m-d H:i:s',time()-24*60*60);
		$query="select id from admire_temp where adddate>='".$time."' and manid='".$manid."' and agent='".$agent."'";
		$result=mysql_query($query,$dbhread);
        $adr_mailnum=mysql_num_rows($result);
		if($adr_mailnum>=$agentmaxnumin24hour){
			$errMsg['A015']="<p align='left'><font color='#FF0000'><b>對不起﹐系統禁止提交此信。</b></font></p><p align='left'>在同一天(24小時)內，貴機構已經有多位女士向該男士發出了意向信件。</p>";
			return false;
		}
        
        //5.1 检查该女士与该男士24小时内有没有提交过意向信，如果有的话，禁发(主要防止刷新页与重复提交2011-6-13 David)
		$query="select id from admire_temp where adddate>='".$time."' AND womanid='".$womanid."' and manid='".$manid."' LIMIT 1";
		$result=mysql_query($query,$dbhread);
        $adr_mailnum=mysql_num_rows($result);
		if($adr_mailnum>0){
			$errMsg['A022']="<p align='left'><font color='#FF0000'><b>對不起﹐系統禁止提交此信。</b></font></p><p align='left'>該女士曾經提交過意向信給此男士。</p>";
			return false;
		}
        

		//6.男士当天收到多于manmaxnumoneday封意向信即禁发 2006-09-06
		//$query="select sent from man_admire where manid='$manid' and sent>=3";
        $row=$memberdb->GetMemberInfo($manid,'sent',TABLE_STATS_ADMIRE,array('where'=>'sent>='.$manmaxnumoneday));
		//$result=mysql_query($query,$dbhread);
		//if(mysql_num_rows($result)>0){
		if(is_array($row)){            
            $errMsg['A017']="<p align='left'><font color=#FF0000>對不起！系統禁止提交該信件！</font><BR>建議﹕請女士改天再提交或考慮其它男士﹗<BR><BR>系統限定了每位男士每日收意向信件數量。謝謝理解!</p>";
			return false;
		}


		//7.同一女士一天內發送意向信不能超過机构设定值
		//北京時間改回为GMT时间限制 - 2007-01-12
		$query="select id from admire_temp  where agent='".$agent."' and womanid='".$womanid."' and  adddate >='".date('Y-m-d 00:00:00')."' ";
		$result=mysql_query($query,$dbhread);
		echo mysql_error();
		$adr_mailnum=mysql_num_rows($result);
			
		if($adr_mailnum>=$admire_max){
			$errMsg['A016']="<p align='left'><font color=#FF0000>對不起！系統禁止提交該信件！</font><BR><BR>貴機構目前意向信的最大許可值爲 ".$admire_max."，即系統只允許單個女士在24小時內發出的意向信數量不超過".$admire_max."封，故此信禁發。<BR><BR><b>提示：</b><BR>系統會定期自動統計和評估各機構意向信件的數量和回復率，調整機構單個女士單日最大意向信的數量的許可值。<a href='javascript:Show(\"/clagt/guide/help/detail.php?id=90\");' class='nor'>點擊查看詳情</a>。</p>";
			return false;
		}
	}	


	if ($action=='1'){	

		//8.男士在5天內EMF通信關係超過50對時﹐禁发 2008-02-19
        if($paidmember){ //只有是付费会员时才检测这个条件
            $query="select memberid from hotmember where memberid='$manid' and mbtype='m' and num>50";
            $result=mysql_query($query,$dbhread);
            if(mysql_num_rows($result)>0){
                $errMsg['A018']="<p align='left'><font color=#FF0000>對不起！系統禁止提交該信件！</font><BR>原因：該男士在過去5天內，通信關係過多，系統暫時禁止女士向其發送意向信件﹗</p>";
                return false;
            }
        }

		//9.女士在5天內EMF通信關係超過8對時﹐禁发 2008-02-19; 且其中最后一封信是男士来信的关系超过（包含）3对 2008-10-22
		$query="select memberid from hotmember where memberid='$womanid' and mbtype='w' and mw_num>2 AND num>".$womanmaxnumemf;
		$result=mysql_query($query,$dbhread);
		if(mysql_num_rows($result)>0){
			$errMsg['A019']="<p align='left'><font color=#FF0000>對不起！系統禁止提交該信件！</font><BR>原因：該女士在過去5天內，通信關係係過多。系統暫時禁止此女士會員發送意向信件。</p>";
			return false;
		}


		//10.检查是否男士发过CupidNote给女士
		$query="select id2,review from cupid1 where manid='".$manid."' and womanid='".$womanid."' and agentid='".$agent."' and review IN('N','Y')";
		$result=mysql_query($query,$dbhread);	
		if(mysql_num_rows($result)>0){
			$cupid=mysql_fetch_assoc($result);
			if($cupid['review']=='N'){
				$str="該男士已經通過比特傳情服務給女士發送了“比特傳情”。<br>該比特情語在等待亞媒審核。";
			}else{
				$str="該男士已經通過比特傳情服務給女士發送了“比特傳情”。<br><a href=\"javascript:Show('/clagt/cupidnote/view_reply2.php?noteid=".$cupid['id2']."')\" class='nor'>請點幾查看&gt;&gt;</a>";
			}

			$errMsg['A009']="提示：系統禁止提交。<br>原因：".$str;

			//更新FAV表
			disableFavoriteAdr($manid,$womanid);

			return false;
		}


		//11.檢查是否發過意向信
		$tempdate=date("Y-m-d 00:00:00",strtotime("-1 month"));
		$query="select sendflag,resubmit,submit_date from ".$dbinfo['tb_adrmain_all']." where submit_date>'".$tempdate."' and manid='".$manid."' and  hideflag='N' and womanid='".$womanid."'";
		//echo $query;

		$result=mysql_query($query,$dbhread);
		echo mysql_error();
		$result_num = mysql_num_rows($result);
		if ($result_num>0) {
			$mailrow=mysql_fetch_assoc($result);
			$tempsubmitdate=date('Y-m-d',strtotime($mailrow["submit_date"]));
			if($mailrow['sendflag']=='Y'){		
				$errMsg['A010']="對不起，系統禁止該意向信件提交！<br>原因﹕該女士在".$tempsubmitdate."曾經提交過意向信給此男士。<BR>目前﹐該意向信件已經成功通過審閱﹐發送給了男士會員。";
			}

			if($mailrow['sendflag']=='N' || $mailrow['sendflag']=='A'){
				$errMsg['A011']="對不起，系統禁止該意向信件提交！<br>原因﹕該女士在".$tempsubmitdate."曾經提交過意向信給此男士。<BR>目前﹐該意向信件處于待審閱狀態中。";
			}

			if($mailrow['sendflag']=='D' and $mailrow['resubmit']=='Y'){
				$errMsg['A012']="對不起，系統禁止該意向信件提交！<br>原因﹕該女士在".$tempsubmitdate."曾經提交過意向信給此男士。<BR>目前﹐該意向信件已經被禁發﹐但允許修改後重新提交。";
			}

			if($mailrow['sendflag']=='D' and $mailrow['resubmit']=='N'){
				$errMsg['A013']="對不起，系統禁止該意向信件提交！<br>原因﹕該女士在".$tempsubmitdate."曾經提交過意向信給此男士。<BR>目前﹐該意向信件已經被禁發﹐且不可修改和重提交。";
			}
			return false;
		}


	}



	$info["woman"]	= $womaninfo;
	$info["man"]	= $maninfo;	
	return $info;
}
?>