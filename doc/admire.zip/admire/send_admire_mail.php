<?
session_start();
//session_register("_tmpAdr");
include_once("../../fun.php");
include_once("../../function-images.php");
include_once("../agentcheck.php");
include_once("../../mysqlopen.php");
include_once("../../comm.php");
include_once("../../function.php");
include_once("template/comm.php");
include_once("../../phpmailer/class.phpmailer.php");
include_once("../../mutidbconn.php");

$manid		= strtoupper(trim($manid));
$womanid	= strtoupper(trim($womanid));
$at_code	= strtoupper(trim($at_code));
$memberdb = new MemberDB();


$dbinfo['tb_adrmain_1m']='ammsg01_1m';
$dbinfo['tb_adrdetail_1m']='ammsg02_1m';

//取得模板数据
$query = "SELECT * FROM `admire_template` WHERE `owner`='".$_sessAgent['agentid']."' AND `womanid`='".$womanid."' AND `template_type`='A' AND `at_status`='A' AND `at_code`='".$at_code."' LIMIT 1";
$at_result = mysql_query($query , $dbh);
$tpl_row = mysql_fetch_assoc($at_result);
if(empty($tpl_row['womanid']) || empty($tpl_row['at_code'])){
	errMsg(array("该模板ID找不到。"),"adr_error.php");
}


if ($manid == "") {
    $errMsg[]="請輸入男士編號!";
	errMsg($errMsg,"adr_error.php");
}
/*
if($REQUEST_METHOD=='POST'){
	if(!isset($_COOKIE["formno[$womanid]"])){
		setcookie("formno[$womanid]",$form_no,time()+3600*6);
	}else{
		$_COOKIE["formno[$womanid]"]=$form_no;
	}
}


if ($womanid == "") {
    $errMsg[]="請輸入女士編號!";
	errMsg($errMsg,"adr_error.php");
}

if ($agreeLaw != "Y"){
	$errMsg[]="對不起! 不認可聲明的翻譯/工作人員禁止發送此信。";
	errMsg($errMsg,"adr_error.php");
}

if ($form_no == ""){
	$errMsg[]="請填入該女士的意向信發送申請單編號。";
	errMsg($errMsg,"adr_error.php");
}

if ($lady_tel == ""){
	$errMsg[]="請填入您聯繫該女士的所用的電話號碼（包括城市區號）";
	errMsg($errMsg,"adr_error.php");
}

if ($body == "") {
	$errMsg[]="請輸入郵件內容";
	errMsg($errMsg,"adr_error.php");
}*/


//发送前检测
$info=checkAdrMail($womanid,$manid,$_sessAgent['agentid'],2); #admire-check.php中定义
errMsg($errMsg,"adr_error.php");

$womanname = mysql_escape_string($info['woman']['firstname']);
$manname   = mysql_escape_string($info['man']['firstname']." ".$info['man']['lastname']);
$manfirstname = mysql_escape_string($info['man']['firstname']);
$groupid = trim($info['woman']['groupid']);
$submit_date = date("Y-m-d H:i:s");
//$review_mode = $info['agent']['admire_reviewer']=='E'?"1":"0";	//审核模式
$review_mode = 0;//由于改为 模板 发送邮件因此这里应该是默认为0

//写入过渡表 2008-03-27
$query="INSERT INTO admire_temp set womanid='$womanid',manid='$manid',adddate='$submit_date',agent='".$_sessAgent['agentid']."'";
$result=mysql_query($query,$dbh);
if(!$result){
	sendErrReprot('代理機構發意向信出錯,寫过渡表不成功',$query);
	$errMsg[]="發意向信出錯,請與Chnlove工作人員聯繫[error:10043]";
	errMsg($errMsg,"adr_error.php");
}else{
	$msgid = mysql_insert_id($dbh);
}


//附件信息(2008-08-01)
//$fileinfo=getattachinfo($womanid,$attachfilephoto);
$attachArray=array();
if($tpl_row['attachment']!=""){
	$attachArray = explode("|", substr($tpl_row['attachment'], 0, -1));
}
$fileinfo['num'] = count($attachArray);

if($fileinfo['num']>0){
    $fileinfo['txt'] = implode('.jpg|',$attachArray).".jpg";
}

//写入主表
$dbinfo['tb_adrmain_1m']='ammsg01_1m';

/*
$query="INSERT INTO ".$dbinfo['tb_adrmain_unsend']." set id='$msgid',womanid='$womanid',womanname='$womanname',manid='$manid',manname='$manname',submit_date='$submit_date',readflag='N',replyflag='0',hideflag='N',agent='".$_sessAgent['agentid']."',agent_staff='".$_sessAgent['staff_id']."',resubmit='Y',sendflag='A',replyid='',form_no='$form_no',deleted='N',review_mode='$review_mode',attachnum='".$fileinfo['num']."'";*/
$query = "INSERT INTO ".$dbinfo['tb_adrmain_1m']." set 	id='$msgid',
													    womanid='$womanid',
														womanname='$womanname',
														sendmode='1',
														template_id='".$tpl_row['at_code']."',
														manid='$manid',
														manname='$manname',
														submit_date='$submit_date',
														sent_date='$submit_date',
														readflag='N',
														replyflag='0',
														hideflag='N',
														agent='".$_sessAgent['agentid']."',
														agent_staff='".$_sessAgent['staff_id']."',
														resubmit='Y',
														sendflag='Y',
														replyid='',
														form_no='$form_no',
														deleted='N',
														review_mode='$review_mode',
														attachnum='".$fileinfo['num']."',
														groupid='".$groupid."'";
$result=mysql_query($query,$dbh);
if(!$result){
	sendErrReprot('代理機構發意向信出錯,寫主表不成功',$query);
	$errMsg[]="發意向信出錯,請與Chnlove工作人員聯繫[error:10044]";
}
//意向信表中的自动ID，以前是写入过渡表时的ID，不过不需要写入过渡表，因此再此重新创建
//$msgid = mysql_insert_id($dbh);

//写入从表
$review_history="提交﹕".date("Y-m-d H:i:s")."GMT  IP:".$REMOTE_ADDR."  電腦編號﹕".$_sessAgent['computer_id']." 工作人員:".$_sessAgent['staff_name']."[".$_sessAgent['staff_id']."]";
/*
$query="INSERT INTO ".$dbinfo['tb_adrdetail_unsend']." set id='$msgid',body='$body',reviewer='',lady_tel='$lady_tel',denyreason='',review_history='$review_history',ip='$REMOTE_ADDR',computerid='".$_sessAgent['computer_id']."',attachment='".$fileinfo['txt']."'";*/
$Greet = '<p align="left">'.$tpl_row['at_greet'].'&nbsp;'.$manfirstname.',</p><br />';
$Line = "<br /><br /><p align=\"center\" style=\"color:#666;width:100%;background:#f1f1f1;padding:2px 0;\">Original Text Written by the Lady</p><br /><br /><p align='left'>".$tpl_row['at_greet'].'&nbsp;'.$manfirstname.",</p><br />";
$body	= addslashes($Greet.$tpl_row['at_content_en'].($tpl_row['at_show_cn']=='Y' && $tpl_row['at_content_cn']!=''?$Line.$tpl_row['at_content_cn']:""));
$admirebody = $Greet.$tpl_row['at_content_en'].($tpl_row['at_show_cn']=='Y' && $tpl_row['at_content_cn']!=''?$Line.$tpl_row['at_content_cn']:"");		
$query = "INSERT INTO ".$dbinfo['tb_adrdetail_1m']." set id='$msgid',
														 body='".$body."',
														 reviewer='',
														 lady_tel='$lady_tel',
														 denyreason='',
														 review_history='$review_history',
														 ip='$REMOTE_ADDR',
														 computerid='".$_sessAgent['computer_id']."',
														 attachment='".$fileinfo['txt']."'";
$result=mysql_query($query,$dbh);
if(!$result){
	sendErrReprot('代理機構發意向信出錯,寫從表不成功',$query);	
	$errMsg[]="發意向信出錯,請與Chnlove工作人員聯繫[error:10045]";
}

errMsg($errMsg,"adr_error.php");

//if(strlen($fileinfo['txt'])>0){
setCookie('Cookie_agtAdmirePic',$fileinfo['txt'],time()+3600*24*60);
//}


//更新机构意向信当日限量余数
$query="update agent set admire_sum_balance=admire_sum_balance-1 where agentid='".$_sessAgent['agentid']."'";
mysql_query($query,$dbh);


//更新男士会员当日意向信提交数量2010-1-4
$updatelist=array(
	'day1'=>'day1+1',
	'total'=>'total+1'
);
$memberdb->setMemberInfoByID(TABLE_STATS_ADMIRE,$updatelist,$manid,false);  
#更新mysqldb_memberdb.stats_admire_cl表,SQL相当: update mysqldb_memberdb.stats_admire_cl set day1=day1+1,total=total+1 where manid=$manid
#其它几个站表名为: stats_admire_ld,stats_admire_ru,stats_admire_th = LD/CD/IDA


//写入工作人员本月发意向信数量 2008-03-27
$query="UPDATE admire_reply_rate SET num_submit=num_submit+1,num_sent=num_sent+1 WHERE staff_id='".$_sessAgent['staff_id']."' AND smonth='".date("Y-m-01")."' AND agent='".$_sessAgent['agentid']."' LIMIT 1";
mysql_query($query,$dbh);
if(mysql_affected_rows($dbh)<=0){
	$query="INSERT INTO admire_reply_rate SET agent='".$_sessAgent['agentid']."', smonth='".date("Y-m-01")."', staff_id='".$_sessAgent['staff_id']."', staff_name='".$_sessAgent['staff_name']."', num_submit='1', num_sent='1', num_reply='0'";
	mysql_query($query,$dbh);
}


//更新FAV表
disableFavoriteAdr($manid,$womanid);







//以前审核功能的部分代码,以前需要审核信件，现在不需要，摘必须功能
if($msgid!=''){

	$adrmsg01 = 'ammsg01_1m';
	$adrmsg02 = 'ammsg02_1m';
	
	$updatelist=array(
		'sent'=>'sent+1'
	);
	$memberdb->setMemberInfoByID(TABLE_STATS_ADMIRE,$updatelist,$manid,false);
			
	
	if (is_array($info)){
		if( $info['man']['admirer_notify']=='1' )
        {
            $mailDb         = mutiDbConn('EMAILSYSTEM');
            $whereAnd       = array();
            $query          = array();
            $whereAnd[]     = 'manid = "' . $manid . '"';
            $whereAnd[]     = 'womansiteid = 0';
            $whereAnd[]     = 'type = 2';
            $whereAnd[]     = 'status = "N"';
            $sql            = 'SELECT * FROM msg_process_list';
            $sql            .= ' WHERE ' . implode(' AND ', $whereAnd);
            
            
            $result         = mysql_query($sql, $mailDb);
            $womaninfo      = array();
            $womaninfo['birthday']  = $info['woman']['birthday'];
            $womaninfo['firstname'] = $info['woman']['firstname'];
            $womaninfo['lastname']  = $info['woman']['lastname'];
            $womaninfo['country']   = $info['woman']['country'];
            $womaninfo['owner']     = $info['woman']['owner'];
            $womaninfo['id']        = $info['woman']['id'];
            $womaninfo['womanid']   = $womanid;
            $womaninfo['height']    = $info['woman']['height'];
            $womaninfo['weight']    = $info['woman']['weight'];
            $womaninfo['marry']     = $info['woman']['marry'];
            $womaninfo['admireInfo']= substr($admirebody, 0, 200);
            $womaninfo['admireId']	= encrypt_win($msgid);
            $womaninfo['province']  = $info['woman']['province'];
            
            if(mysql_num_rows($result) > 0){
                $updateInfo     = array();
                
                $admireInfo  	= mysql_fetch_assoc($result);
                $updateInfo[]   = 'number = ' . ($admireInfo['number'] + 1);
                $updateInfo[]   = 'lastupdatetime = "' . date('Y-m-d H:i:s') . '"';
                $wInfo          = !empty($admireInfo['info']) ? unserialize($admireInfo['info']) : array();
                if(!empty($wInfo) && count($wInfo) == 1) $wInfo[0]['admireInfo'] = '';
                $womaninfo['admireInfo']= '';
                $wInfo          = array_merge(array($womaninfo), $wInfo);
                $updateInfo[]   = 'info = "' . addslashes(serialize($wInfo)) . '"';
                $query          = 'UPDATE msg_process_list SET ' . implode(', ', $updateInfo) . ' WHERE id = ' . $admireInfo['id'];
            }else{
                $insertInfo     = array();
                $insertInfo[]   = 'manid        = "' . $info["man"]['manid'] . '"';
                $insertInfo[]   = 'firstname    = "' . mysql_real_escape_string($info["man"]['firstname']) . '"';
                $insertInfo[]   = 'lastname     = "' . mysql_real_escape_string($info["man"]['lastname']) . '"';
                $insertInfo[]   = 'email        = "' . mysql_real_escape_string($info["man"]['email']) . '"';
                $insertInfo[]   = 'sid          = "' . $info["man"]['sid'] . '"';
                $insertInfo[]   = 'type         = 2';
                $insertInfo[]   = 'addtime      = "' . date('Y-m-d H:i:s') . '"';
                $insertInfo[]   = 'senthour     = ' . fmod($info["man"]['id'], 24);
                $insertInfo[]   = 'womansiteid  = 0';
                $wInfo[]        = $womaninfo;
                $insertInfo[]   = 'info         = "' . addslashes(serialize($wInfo)) . '"';
                $insertInfo[]   = 'number       = 1';
                $insertInfo[]   = 'lastupdatetime = "' . date('Y-m-d H:i:s') . '"';
                $insertInfo[]   = 'status       = "N"';
                $query          = 'INSERT INTO msg_process_list SET ' . implode(', ', $insertInfo);
            } 
            if(!empty($query))
            {
                $rs             = mysql_query($query, $mailDb);
                if(!$rs)
                {
                    sendErrReprot('意向信通知信邮件写入错误',$query);
                }
            }
        }		
	
	}else{
		$aa=false;
		sendErrReprot('通知信發送不成功！','');
	}


}











//session_unregister("_tmpAdr");
$msgid=encrypt_win($msgid);
header("Location:adr_succ2.php?manid=".$manid."&womanid=".$womanid."&messageid=".$msgid);
die();
?>
